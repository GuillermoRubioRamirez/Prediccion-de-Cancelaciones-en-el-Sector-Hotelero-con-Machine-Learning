# R6_repositorio_verdeoscuro

En este readme se detallará la estructura que tiene este proyecto de Python. El proyecto contiene una carpeta con los datos, seis notebooks (01-Aemet, 02-Preprocesamiento, 03-Modelizacion, 04-Graficos, 05-Big_Data y 06-Wordcloud_libere) y un archivo .yml con el contenido necesario para crear el entorno que se ha utilizado para realizar el reto.

En cuanto a la carpeta de datos, dentro se encuentran otras dos carpetas, una con los datos originales y otra con los datos limpios. Los datos originales son los que nos proporcionó Líbere al principio y los datos limpios son los que se han ido generando a lo largo del reto.

En lo que respecta a los notebooks, el primero contiene el código necesario para obtener los datos meteorológicos de AEMET. No necesita ningún input ya que los datos se extraen desde la API de AEMET y el output que genera es un archivo .csv llamado "datos_meteo.csv". 

El segundo tiene todo el código necesario para el preprocesamiento de los datos. Esto incluye por un lado, el análisis de duplicados, missings y anomalías del dataset de las reservas, y su correspondiente imputación o procesamiento. Por otro lado, incluye la unión del anterior dataset con los datos meteorológicos, creación de los dummies y análisis de las correlaciones. Los inputs que necesita este notebook son el archivo llamado "cancellation_data.csv" que se encuentra en la carpeta de datos originales y el archivo llamado "datos_meteo.csv" que se ubica en datos limpios. Los outputs que genera son los archivos .csv llamados "datos_limpios.csv" y "datos_para_modelo.csv".

El tercer notebook contiene el código necesario para la modelización de los datos. El input que necesita es el csv generado en el anterior notebook "datos_para_modelo.csv" y no genera ningún output.

En cuanto al cuarto notebook, este tiene el código necesario para realizar todos los gráficos. El input que necesita es el csv "datos_limpios.csv" y no genera outputs.

El quinto notebook contiene el código para realizar la tarea que se pedía en la asignatura de Big Data y se tiene que ejecutar dentro de la máquina virtual. El input que necesita es el csv "datos_meteo.csv" y no genera ningún output. 

Por último, el sexto notebook tiene el código para hacer la tarea que se pedía en la asignatura de Data Science. No necesita ningún input ni tampoco genera ningún output.